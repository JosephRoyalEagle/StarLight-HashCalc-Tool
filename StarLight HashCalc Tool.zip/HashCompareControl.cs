﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;
using System.Security.Policy;

namespace StarLight_HashCalc_Tool
{
    public partial class HashCompareControl : UserControl
    {
        public HashCompareControl()
        {
            InitializeComponent();
        }

        private void btn_compare_clean_hash_Click(object sender, EventArgs e)
        {
            tb_compare_hash.Text = string.Empty;
            tb_file_route_compare_hash.Text = string.Empty;
            combo_compare_hash.SelectedIndex = -1;
        }

        private void btn_compare_select_hash_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Select a file";
            openFileDialog.Filter = "Text file (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string selectedFilePath = openFileDialog.FileName;
                tb_file_route_compare_hash.Text = selectedFilePath;
            }
        }

        private void btn_compare_gen_hash_Click(object sender, EventArgs e)
        {
            if (combo_compare_hash.SelectedItem != null)
            {
                if (string.IsNullOrWhiteSpace(tb_file_route_compare_hash.Text))
                {
                    MessageBox.Show("Please select a file.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    if (string.IsNullOrWhiteSpace(tb_compare_hash.Text))
                    {
                        MessageBox.Show("Please paste the hash you want to compare.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                    else
                    {
                        string combo_text_hash_c_valeur = combo_compare_hash.SelectedItem.ToString();
                        string filePath_valeur = tb_file_route_compare_hash.Text;
                        string texthash_valeur = tb_compare_hash.Text;

                        try
                        {
                            string hashfiletext = GenerateHash(filePath_valeur, combo_text_hash_c_valeur);
                            if (hashfiletext == texthash_valeur)
                            {
                                MessageBox.Show("The hashes are identical.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            }
                            else
                            {
                                MessageBox.Show("The hashes are different.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                            
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an item.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private string GenerateHash(string filePath, string algorithm)
        {
            using (HashAlgorithm hashAlgorithm = HashAlgorithm.Create(algorithm))
            {
                if (hashAlgorithm == null)
                {
                    throw new ArgumentException("Invalid hash algorithm specified");
                }

                using (FileStream stream = File.OpenRead(filePath))
                {
                    byte[] hashBytes = hashAlgorithm.ComputeHash(stream);
                    return BitConverter.ToString(hashBytes).Replace("-", string.Empty);
                }
            }
        }
    }
}
