﻿namespace StarLight_HashCalc_Tool
{
    partial class HashFileControl
    {
        /// <summary> 
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur de composants

        /// <summary> 
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas 
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            this.panel1 = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.combo_file_hash = new System.Windows.Forms.ComboBox();
            this.btn_file_select_hash = new System.Windows.Forms.Button();
            this.tb_file_route_hash = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.tb_file_hash = new System.Windows.Forms.TextBox();
            this.btn_file_clean_hash = new System.Windows.Forms.Button();
            this.btn_file_copy_hash = new System.Windows.Forms.Button();
            this.btn_file_gen_hash = new System.Windows.Forms.Button();
            this.panel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(220)))), ((int)(((byte)(221)))), ((int)(((byte)(225)))));
            this.panel1.Controls.Add(this.label2);
            this.panel1.Controls.Add(this.combo_file_hash);
            this.panel1.Controls.Add(this.btn_file_select_hash);
            this.panel1.Controls.Add(this.tb_file_route_hash);
            this.panel1.Controls.Add(this.label1);
            this.panel1.Controls.Add(this.label5);
            this.panel1.Controls.Add(this.tb_file_hash);
            this.panel1.Controls.Add(this.btn_file_clean_hash);
            this.panel1.Controls.Add(this.btn_file_copy_hash);
            this.panel1.Controls.Add(this.btn_file_gen_hash);
            this.panel1.Location = new System.Drawing.Point(15, 14);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(584, 416);
            this.panel1.TabIndex = 1;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Lora", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(383, 88);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(78, 22);
            this.label2.TabIndex = 21;
            this.label2.Text = "Algorithm";
            // 
            // combo_file_hash
            // 
            this.combo_file_hash.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
            this.combo_file_hash.Font = new System.Drawing.Font("Lora", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.combo_file_hash.FormattingEnabled = true;
            this.combo_file_hash.IntegralHeight = false;
            this.combo_file_hash.Items.AddRange(new object[] {
            "SHA-256",
            "SHA-384",
            "SHA-512",
            "MD5",
            "RIPEMD160"});
            this.combo_file_hash.Location = new System.Drawing.Point(387, 113);
            this.combo_file_hash.Name = "combo_file_hash";
            this.combo_file_hash.Size = new System.Drawing.Size(178, 37);
            this.combo_file_hash.TabIndex = 20;
            // 
            // btn_file_select_hash
            // 
            this.btn_file_select_hash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(165)))), ((int)(((byte)(177)))), ((int)(((byte)(194)))));
            this.btn_file_select_hash.FlatAppearance.BorderSize = 0;
            this.btn_file_select_hash.Font = new System.Drawing.Font("Lora", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_file_select_hash.Location = new System.Drawing.Point(412, 39);
            this.btn_file_select_hash.Name = "btn_file_select_hash";
            this.btn_file_select_hash.Padding = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btn_file_select_hash.Size = new System.Drawing.Size(153, 36);
            this.btn_file_select_hash.TabIndex = 19;
            this.btn_file_select_hash.Text = "Select file";
            this.btn_file_select_hash.UseVisualStyleBackColor = false;
            this.btn_file_select_hash.Click += new System.EventHandler(this.btn_file_select_hash_Click);
            // 
            // tb_file_route_hash
            // 
            this.tb_file_route_hash.Font = new System.Drawing.Font("Lora", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_file_route_hash.Location = new System.Drawing.Point(19, 39);
            this.tb_file_route_hash.Multiline = true;
            this.tb_file_route_hash.Name = "tb_file_route_hash";
            this.tb_file_route_hash.ReadOnly = true;
            this.tb_file_route_hash.Size = new System.Drawing.Size(387, 36);
            this.tb_file_route_hash.TabIndex = 18;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Lora", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(15, 14);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(70, 22);
            this.label1.TabIndex = 17;
            this.label1.Text = "File path";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Lora", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(15, 90);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(46, 22);
            this.label5.TabIndex = 15;
            this.label5.Text = "Hash";
            // 
            // tb_file_hash
            // 
            this.tb_file_hash.Font = new System.Drawing.Font("Lora", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tb_file_hash.Location = new System.Drawing.Point(19, 115);
            this.tb_file_hash.Multiline = true;
            this.tb_file_hash.Name = "tb_file_hash";
            this.tb_file_hash.ReadOnly = true;
            this.tb_file_hash.Size = new System.Drawing.Size(351, 35);
            this.tb_file_hash.TabIndex = 3;
            // 
            // btn_file_clean_hash
            // 
            this.btn_file_clean_hash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(235)))), ((int)(((byte)(59)))), ((int)(((byte)(90)))));
            this.btn_file_clean_hash.FlatAppearance.BorderSize = 0;
            this.btn_file_clean_hash.Font = new System.Drawing.Font("Lora", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_file_clean_hash.Location = new System.Drawing.Point(412, 160);
            this.btn_file_clean_hash.Name = "btn_file_clean_hash";
            this.btn_file_clean_hash.Padding = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btn_file_clean_hash.Size = new System.Drawing.Size(153, 44);
            this.btn_file_clean_hash.TabIndex = 2;
            this.btn_file_clean_hash.Text = "Clean";
            this.btn_file_clean_hash.UseVisualStyleBackColor = false;
            this.btn_file_clean_hash.Click += new System.EventHandler(this.btn_file_clean_hash_Click);
            // 
            // btn_file_copy_hash
            // 
            this.btn_file_copy_hash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(250)))), ((int)(((byte)(130)))), ((int)(((byte)(49)))));
            this.btn_file_copy_hash.FlatAppearance.BorderSize = 0;
            this.btn_file_copy_hash.Font = new System.Drawing.Font("Lora", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_file_copy_hash.Location = new System.Drawing.Point(217, 160);
            this.btn_file_copy_hash.Name = "btn_file_copy_hash";
            this.btn_file_copy_hash.Padding = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btn_file_copy_hash.Size = new System.Drawing.Size(153, 44);
            this.btn_file_copy_hash.TabIndex = 1;
            this.btn_file_copy_hash.Text = "Copy hash";
            this.btn_file_copy_hash.UseVisualStyleBackColor = false;
            this.btn_file_copy_hash.Click += new System.EventHandler(this.btn_file_copy_hash_Click);
            // 
            // btn_file_gen_hash
            // 
            this.btn_file_gen_hash.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(189)))), ((int)(((byte)(50)))));
            this.btn_file_gen_hash.FlatAppearance.BorderSize = 0;
            this.btn_file_gen_hash.Font = new System.Drawing.Font("Lora", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_file_gen_hash.Location = new System.Drawing.Point(19, 160);
            this.btn_file_gen_hash.Name = "btn_file_gen_hash";
            this.btn_file_gen_hash.Padding = new System.Windows.Forms.Padding(2, 0, 2, 0);
            this.btn_file_gen_hash.Size = new System.Drawing.Size(153, 44);
            this.btn_file_gen_hash.TabIndex = 0;
            this.btn_file_gen_hash.Text = "Generate hash";
            this.btn_file_gen_hash.UseVisualStyleBackColor = false;
            this.btn_file_gen_hash.Click += new System.EventHandler(this.btn_file_gen_hash_Click);
            // 
            // HashFileControl
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.panel1);
            this.Name = "HashFileControl";
            this.Size = new System.Drawing.Size(615, 445);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox tb_file_hash;
        private System.Windows.Forms.Button btn_file_clean_hash;
        private System.Windows.Forms.Button btn_file_copy_hash;
        private System.Windows.Forms.Button btn_file_gen_hash;
        private System.Windows.Forms.TextBox tb_file_route_hash;
        private System.Windows.Forms.Button btn_file_select_hash;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.ComboBox combo_file_hash;
    }
}
