﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using System.Security.Cryptography;

namespace StarLight_HashCalc_Tool
{
    public partial class HashTextControl : UserControl
    {
        public HashTextControl()
        {
            InitializeComponent();
        }

        private void btn_text_clean_hash_Click(object sender, EventArgs e)
        {
            tb_text_paste_hash.Text = string.Empty;
            tb_text_hash.Text = string.Empty;
            combo_text_hash.SelectedIndex = -1;
        }

        private void btn_text_gen_hash_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_text_paste_hash.Text))
            {
                MessageBox.Show("The text field must not be empty.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                if (combo_text_hash.SelectedItem != null)
                {
                    string tb_text_paste_hash_c_text = tb_text_paste_hash.Text;
                    string combo_text_hash_c_valeur = combo_text_hash.SelectedItem.ToString();

                    try
                    {
                        string hashedText = GenerateHash(tb_text_paste_hash_c_text, combo_text_hash_c_valeur);
                        tb_text_hash.Text = hashedText;
                        MessageBox.Show("Hash generated successfully. ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Error while hashing : " + ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
                else
                {
                    MessageBox.Show("Please select an item.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private string GenerateHash(string input, string algorithm)
        {
            using (HashAlgorithm hashAlgorithm = HashAlgorithm.Create(algorithm))
            {
                if (hashAlgorithm == null)
                {
                    throw new ArgumentException("Invalid hash algorithm specified");
                }

                byte[] inputBytes = Encoding.UTF8.GetBytes(input);
                byte[] hashBytes = hashAlgorithm.ComputeHash(inputBytes);
                return BitConverter.ToString(hashBytes).Replace("-", string.Empty);
            }
        }

        private void btn_text_copy_hash_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_text_hash.Text))
            {
                MessageBox.Show("You have not yet generated a hash.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string tb_text_hash_c_text = tb_text_hash.Text;
                Clipboard.SetText(tb_text_hash_c_text);
                MessageBox.Show("Text copied to clipboard successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
    }
}
