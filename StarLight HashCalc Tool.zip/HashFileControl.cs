﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

namespace StarLight_HashCalc_Tool
{
    public partial class HashFileControl : UserControl
    {
        public HashFileControl()
        {
            InitializeComponent();
        }

        private void btn_file_select_hash_Click(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.Title = "Select a file";
            openFileDialog.Filter = "Text file (*.txt)|*.txt|All files (*.*)|*.*";
            openFileDialog.FilterIndex = 1;
            openFileDialog.RestoreDirectory = true;

            if (openFileDialog.ShowDialog() == DialogResult.OK)
            {
                string selectedFilePath = openFileDialog.FileName;
                tb_file_route_hash.Text = selectedFilePath;
            }
        }

        private void btn_file_clean_hash_Click(object sender, EventArgs e)
        {
            tb_file_hash.Text = string.Empty;
            tb_file_route_hash.Text = string.Empty;
            combo_file_hash.SelectedIndex = -1;
        }

        private void btn_file_copy_hash_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrWhiteSpace(tb_file_hash.Text))
            {
                MessageBox.Show("You have not yet generated a hash.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            else
            {
                string tb_text_hash_c_text = tb_file_hash.Text;
                Clipboard.SetText(tb_text_hash_c_text);
                MessageBox.Show("Text copied to clipboard successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btn_file_gen_hash_Click(object sender, EventArgs e)
        {
            if (combo_file_hash.SelectedItem != null)
            {
                if (string.IsNullOrWhiteSpace(tb_file_route_hash.Text))
                {
                    MessageBox.Show("Please select a file.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
                else
                {
                    string combo_text_hash_c_valeur = combo_file_hash.SelectedItem.ToString();
                    string filePath_valeur = tb_file_route_hash.Text;

                    try
                    {
                        string hashfiletext = GenerateHash(filePath_valeur, combo_text_hash_c_valeur);
                        tb_file_hash.Text = hashfiletext;
                        MessageBox.Show("Hash generated successfully. ", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"An error occurred: {ex.Message}", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            else
            {
                MessageBox.Show("Please select an item.", "Warning", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }

        }

        private string GenerateHash(string filePath, string algorithm)
        {
            using (HashAlgorithm hashAlgorithm = HashAlgorithm.Create(algorithm))
            {
                if (hashAlgorithm == null)
                {
                    throw new ArgumentException("Invalid hash algorithm specified");
                }

                using (FileStream stream = File.OpenRead(filePath))
                {
                    byte[] hashBytes = hashAlgorithm.ComputeHash(stream);
                    return BitConverter.ToString(hashBytes).Replace("-", string.Empty);
                }
            }
        }
    }
}
