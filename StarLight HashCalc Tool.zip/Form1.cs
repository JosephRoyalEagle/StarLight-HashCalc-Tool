﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarLight_HashCalc_Tool
{
    public partial class fst_screen : Form
    {
        public fst_screen()
        {
            InitializeComponent();
            btn_indicator.Height = btn_home.Height;
            btn_indicator.Top = btn_home.Top;
            homeControlScreen.BringToFront();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btn_home_Click(object sender, EventArgs e)
        {
            btn_indicator.Height = btn_home.Height;
            btn_indicator.Top = btn_home.Top;
            homeControlScreen.BringToFront();
        }

        private void homeControlScreen_Load(object sender, EventArgs e)
        {

        }

        private void btn_hash_text_Click(object sender, EventArgs e)
        {
            btn_indicator.Height = btn_hash_text.Height;
            btn_indicator.Top = btn_hash_text.Top;
            hashTextControl.BringToFront();
        }

        private void btn_hash_file_Click(object sender, EventArgs e)
        {
            btn_indicator.Height = btn_hash_file.Height;
            btn_indicator.Top = btn_hash_file.Top;
            hashFileControl2.BringToFront();
        }

        private void btn_compare_hash_Click(object sender, EventArgs e)
        {
            btn_indicator.Height = btn_compare_hash.Height;
            btn_indicator.Top = btn_compare_hash.Top;
            hashCompareControl1.BringToFront();
        }

        private void hashTextControl_Load(object sender, EventArgs e)
        {
        }

        private void btn_support_us_Click(object sender, EventArgs e)
        {
            btn_indicator.Height = btn_support_us.Height;
            btn_indicator.Top = btn_support_us.Top;
            donateControl1.BringToFront();
        }
    }
}
