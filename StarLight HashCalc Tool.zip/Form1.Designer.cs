﻿namespace StarLight_HashCalc_Tool
{
    partial class fst_screen
    {
        /// <summary>
        /// Variable nécessaire au concepteur.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Nettoyage des ressources utilisées.
        /// </summary>
        /// <param name="disposing">true si les ressources managées doivent être supprimées ; sinon, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Code généré par le Concepteur Windows Form

        /// <summary>
        /// Méthode requise pour la prise en charge du concepteur - ne modifiez pas
        /// le contenu de cette méthode avec l'éditeur de code.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(fst_screen));
            this.panel1 = new System.Windows.Forms.Panel();
            this.btn_exit = new System.Windows.Forms.Button();
            this.btn_compare_hash = new System.Windows.Forms.Button();
            this.btn_hash_file = new System.Windows.Forms.Button();
            this.btn_hash_text = new System.Windows.Forms.Button();
            this.btn_indicator = new System.Windows.Forms.Panel();
            this.btn_home = new System.Windows.Forms.Button();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.panel4 = new System.Windows.Forms.Panel();
            this.hashFileControl1 = new StarLight_HashCalc_Tool.HashFileControl();
            this.homeControlScreen = new StarLight_HashCalc_Tool.HomeControl();
            this.hashTextControl = new StarLight_HashCalc_Tool.HashTextControl();
            this.hashFileControl2 = new StarLight_HashCalc_Tool.HashFileControl();
            this.hashCompareControl1 = new StarLight_HashCalc_Tool.HashCompareControl();
            this.btn_support_us = new System.Windows.Forms.Button();
            this.donateControl1 = new StarLight_HashCalc_Tool.DonateControl();
            this.panel1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.panel4.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(30)))), ((int)(((byte)(39)))), ((int)(((byte)(46)))));
            this.panel1.Controls.Add(this.btn_exit);
            this.panel1.Controls.Add(this.btn_compare_hash);
            this.panel1.Controls.Add(this.btn_hash_file);
            this.panel1.Controls.Add(this.btn_hash_text);
            this.panel1.Controls.Add(this.btn_indicator);
            this.panel1.Controls.Add(this.btn_home);
            this.panel1.Controls.Add(this.pictureBox1);
            this.panel1.Controls.Add(this.btn_support_us);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Left;
            this.panel1.Location = new System.Drawing.Point(0, 0);
            this.panel1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(278, 692);
            this.panel1.TabIndex = 0;
            // 
            // btn_exit
            // 
            this.btn_exit.FlatAppearance.BorderSize = 0;
            this.btn_exit.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_exit.Font = new System.Drawing.Font("Lora", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_exit.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_exit.Image = ((System.Drawing.Image)(resources.GetObject("btn_exit.Image")));
            this.btn_exit.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_exit.Location = new System.Drawing.Point(28, 605);
            this.btn_exit.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_exit.Name = "btn_exit";
            this.btn_exit.Size = new System.Drawing.Size(256, 69);
            this.btn_exit.TabIndex = 6;
            this.btn_exit.Text = "  Exit";
            this.btn_exit.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_exit.UseVisualStyleBackColor = true;
            this.btn_exit.Click += new System.EventHandler(this.button5_Click);
            // 
            // btn_compare_hash
            // 
            this.btn_compare_hash.FlatAppearance.BorderSize = 0;
            this.btn_compare_hash.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_compare_hash.Font = new System.Drawing.Font("Lora", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_compare_hash.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_compare_hash.Image = ((System.Drawing.Image)(resources.GetObject("btn_compare_hash.Image")));
            this.btn_compare_hash.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_compare_hash.Location = new System.Drawing.Point(28, 423);
            this.btn_compare_hash.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_compare_hash.Name = "btn_compare_hash";
            this.btn_compare_hash.Size = new System.Drawing.Size(256, 69);
            this.btn_compare_hash.TabIndex = 5;
            this.btn_compare_hash.Text = "  Compare Hash";
            this.btn_compare_hash.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_compare_hash.UseVisualStyleBackColor = true;
            this.btn_compare_hash.Click += new System.EventHandler(this.btn_compare_hash_Click);
            // 
            // btn_hash_file
            // 
            this.btn_hash_file.FlatAppearance.BorderSize = 0;
            this.btn_hash_file.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_hash_file.Font = new System.Drawing.Font("Lora", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_hash_file.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_hash_file.Image = ((System.Drawing.Image)(resources.GetObject("btn_hash_file.Image")));
            this.btn_hash_file.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_hash_file.Location = new System.Drawing.Point(28, 345);
            this.btn_hash_file.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_hash_file.Name = "btn_hash_file";
            this.btn_hash_file.Size = new System.Drawing.Size(220, 69);
            this.btn_hash_file.TabIndex = 4;
            this.btn_hash_file.Text = "  Hash File";
            this.btn_hash_file.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_hash_file.UseVisualStyleBackColor = true;
            this.btn_hash_file.Click += new System.EventHandler(this.btn_hash_file_Click);
            // 
            // btn_hash_text
            // 
            this.btn_hash_text.FlatAppearance.BorderSize = 0;
            this.btn_hash_text.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_hash_text.Font = new System.Drawing.Font("Lora", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_hash_text.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_hash_text.Image = ((System.Drawing.Image)(resources.GetObject("btn_hash_text.Image")));
            this.btn_hash_text.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_hash_text.Location = new System.Drawing.Point(28, 266);
            this.btn_hash_text.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_hash_text.Name = "btn_hash_text";
            this.btn_hash_text.Size = new System.Drawing.Size(220, 69);
            this.btn_hash_text.TabIndex = 3;
            this.btn_hash_text.Text = "  Hash Text";
            this.btn_hash_text.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_hash_text.UseVisualStyleBackColor = true;
            this.btn_hash_text.Click += new System.EventHandler(this.btn_hash_text_Click);
            // 
            // btn_indicator
            // 
            this.btn_indicator.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.btn_indicator.Location = new System.Drawing.Point(10, 188);
            this.btn_indicator.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_indicator.Name = "btn_indicator";
            this.btn_indicator.Size = new System.Drawing.Size(15, 69);
            this.btn_indicator.TabIndex = 1;
            // 
            // btn_home
            // 
            this.btn_home.FlatAppearance.BorderSize = 0;
            this.btn_home.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_home.Font = new System.Drawing.Font("Lora", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_home.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_home.Image = ((System.Drawing.Image)(resources.GetObject("btn_home.Image")));
            this.btn_home.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_home.Location = new System.Drawing.Point(28, 188);
            this.btn_home.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_home.Name = "btn_home";
            this.btn_home.Size = new System.Drawing.Size(220, 69);
            this.btn_home.TabIndex = 2;
            this.btn_home.Text = "  Home";
            this.btn_home.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_home.UseVisualStyleBackColor = true;
            this.btn_home.Click += new System.EventHandler(this.btn_home_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.Image = ((System.Drawing.Image)(resources.GetObject("pictureBox1.Image")));
            this.pictureBox1.Location = new System.Drawing.Point(22, 8);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(204, 169);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // panel4
            // 
            this.panel4.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(68)))), ((int)(((byte)(189)))), ((int)(((byte)(50)))));
            this.panel4.Controls.Add(this.hashFileControl1);
            this.panel4.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel4.Location = new System.Drawing.Point(278, 0);
            this.panel4.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(922, 15);
            this.panel4.TabIndex = 9;
            // 
            // hashFileControl1
            // 
            this.hashFileControl1.Location = new System.Drawing.Point(-4, 0);
            this.hashFileControl1.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.hashFileControl1.Name = "hashFileControl1";
            this.hashFileControl1.Size = new System.Drawing.Size(922, 685);
            this.hashFileControl1.TabIndex = 12;
            // 
            // homeControlScreen
            // 
            this.homeControlScreen.Location = new System.Drawing.Point(278, 15);
            this.homeControlScreen.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.homeControlScreen.Name = "homeControlScreen";
            this.homeControlScreen.Size = new System.Drawing.Size(922, 677);
            this.homeControlScreen.TabIndex = 10;
            this.homeControlScreen.Load += new System.EventHandler(this.homeControlScreen_Load);
            // 
            // hashTextControl
            // 
            this.hashTextControl.Location = new System.Drawing.Point(278, 14);
            this.hashTextControl.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.hashTextControl.Name = "hashTextControl";
            this.hashTextControl.Size = new System.Drawing.Size(922, 678);
            this.hashTextControl.TabIndex = 11;
            this.hashTextControl.Load += new System.EventHandler(this.hashTextControl_Load);
            // 
            // hashFileControl2
            // 
            this.hashFileControl2.Location = new System.Drawing.Point(278, 14);
            this.hashFileControl2.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.hashFileControl2.Name = "hashFileControl2";
            this.hashFileControl2.Size = new System.Drawing.Size(922, 678);
            this.hashFileControl2.TabIndex = 12;
            // 
            // hashCompareControl1
            // 
            this.hashCompareControl1.Location = new System.Drawing.Point(278, 14);
            this.hashCompareControl1.Margin = new System.Windows.Forms.Padding(6, 8, 6, 8);
            this.hashCompareControl1.Name = "hashCompareControl1";
            this.hashCompareControl1.Size = new System.Drawing.Size(922, 678);
            this.hashCompareControl1.TabIndex = 13;
            // 
            // btn_support_us
            // 
            this.btn_support_us.FlatAppearance.BorderSize = 0;
            this.btn_support_us.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btn_support_us.Font = new System.Drawing.Font("Lora", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btn_support_us.ForeColor = System.Drawing.Color.Gainsboro;
            this.btn_support_us.Image = ((System.Drawing.Image)(resources.GetObject("btn_support_us.Image")));
            this.btn_support_us.ImageAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btn_support_us.Location = new System.Drawing.Point(28, 502);
            this.btn_support_us.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.btn_support_us.Name = "btn_support_us";
            this.btn_support_us.Size = new System.Drawing.Size(256, 69);
            this.btn_support_us.TabIndex = 7;
            this.btn_support_us.Text = "  Donate";
            this.btn_support_us.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText;
            this.btn_support_us.UseVisualStyleBackColor = true;
            this.btn_support_us.Click += new System.EventHandler(this.btn_support_us_Click);
            // 
            // donateControl1
            // 
            this.donateControl1.Location = new System.Drawing.Point(278, 13);
            this.donateControl1.Name = "donateControl1";
            this.donateControl1.Size = new System.Drawing.Size(929, 679);
            this.donateControl1.TabIndex = 14;
            // 
            // fst_screen
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1200, 692);
            this.Controls.Add(this.panel4);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.donateControl1);
            this.Controls.Add(this.homeControlScreen);
            this.Controls.Add(this.hashTextControl);
            this.Controls.Add(this.hashCompareControl1);
            this.Controls.Add(this.hashFileControl2);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4, 5, 4, 5);
            this.MaximumSize = new System.Drawing.Size(1200, 692);
            this.MinimumSize = new System.Drawing.Size(1200, 692);
            this.Name = "fst_screen";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "StarLight HashCalc Tool";
            this.panel1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.panel4.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.Button btn_home;
        private System.Windows.Forms.Panel btn_indicator;
        private System.Windows.Forms.Button btn_exit;
        private System.Windows.Forms.Button btn_compare_hash;
        private System.Windows.Forms.Button btn_hash_file;
        private System.Windows.Forms.Button btn_hash_text;
        private System.Windows.Forms.Panel panel4;
        private HomeControl homeControlScreen;
        private HashTextControl hashTextControl;
        private HashFileControl hashFileControl1;
        private HashFileControl hashFileControl2;
        private HashCompareControl hashCompareControl1;
        private System.Windows.Forms.Button btn_support_us;
        private DonateControl donateControl1;
    }
}

