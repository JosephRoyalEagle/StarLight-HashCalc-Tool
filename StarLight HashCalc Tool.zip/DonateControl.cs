﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace StarLight_HashCalc_Tool
{
    public partial class DonateControl : UserControl
    {
        public DonateControl()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            string adress_crypto_text = "bc1qut60yy3le9kchw2guhz5kg5275q66m4009mlqg";
            Clipboard.SetText(adress_crypto_text);
            MessageBox.Show("Bitcoin address copied to clipboard successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            string adress_crypto_text = "0x454F6B96E148bdD46b81163146840505B9741201";
            Clipboard.SetText(adress_crypto_text);
            MessageBox.Show("Ethereum address copied to clipboard successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void button3_Click(object sender, EventArgs e)
        {
            string adress_crypto_text = "rMq9J8FAd1s6u2fcfkkQj6qGyKXnTJYBeg";
            Clipboard.SetText(adress_crypto_text);
            MessageBox.Show("XRP address copied to clipboard successfully.", "Information", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
    }
}
